package lib280.tree;

import lib280.base.Dispenser280;
import lib280.exception.ContainerFull280Exception;
import lib280.exception.DuplicateItems280Exception;
import lib280.exception.NoCurrentItem280Exception;

/**
 name: Ruobing Fu
 NSID: xdt709
 student number: 11319234
 course number:CMPT-280-02
 */

public class ArrayedHeap280<I extends Comparable<? super I>> extends ArrayedBinaryTree280<I> implements Dispenser280<I> {


    /**
     * Constructor.
     *
     * @param cap Maximum number of elements that can be in the lib280.tree.
     */
    public ArrayedHeap280(int cap) {
        super(cap);
        this.items = (I[]) new Comparable[cap+1];


    }

    /**
     * exchange two items on given indexes
     * @param index1
     * @param index2
     */
    public void swap(int index1, int index2)
    {
        I temp = items[index1];
        items[index1] = items[index2];
        items[index2] =temp;
    }


    /**
     * helper method for insertion to maintain the property of heaps.
     * compare the new item with its parent, if it is larger than its parent, swap.
     * @param currentindex : the index of newly inserted item
     */
    protected void insertionHelper(int currentindex){
        int index = currentindex;
        while (index >1 && items[index].compareTo(items[findParent(index)]) > 0) {
            // exchange item and its parent
            swap(findParent(index),index);
            // update the index
            index = findParent(index);
        }
    }



    @Override
    public void insert(I x) throws ContainerFull280Exception, DuplicateItems280Exception{
        //perform insertion in an arrayedtree
        // the cursor points to the postion 1 all the time.
        if (this.isFull()) throw new ContainerFull280Exception("The tree is full,can not insert a new element");
        if (this.isEmpty()) {
            this.items[1] = x;
            this.count++;
            this.currentNode =  this.count;
        }
        else {
            this.items[this.count + 1] = x;
            this.count++;

            insertionHelper(this.count);

        }
        }

    /**
     * helper method for the deleteitem. starting from the first item in the array, compare it with its larget child,
     * if its larger,swap to maintain the property of the heap
     * @param i index of the first item.
     */
        protected void deletionhelper(int i)
        {
            //get the larger child of the node and swap

            while (i<this.count && findLeftChild(i) < this.count){
                //set the largerchild to the left one
                int largerChild = findLeftChild(i);

                if (findRightChild(i) < this.count && items[findRightChild(i)].compareTo(items[largerChild])>0){
                    largerChild = findRightChild(i);
                }
                //compare the parent with its largest kid
                if (largerChild < this.count && items[i].compareTo(items[largerChild])<0){
                    swap(i,largerChild);
                }
                else{
                    break;
                }
                //update the index
                i = largerChild;
            }

        }

// delete item at the cursor position
    @Override
    public void deleteItem() throws NoCurrentItem280Exception {

        // perform deleteitem on an arrayedtree
        if (isEmpty()){ throw new NoCurrentItem280Exception("Container is empty"); }
        if (this.itemExists()) {
            this.items[currentNode] = this.items[count];
            this.items[count] =null;
            count--;
            if (this.currentNode == this.count+1) this.currentNode--;
            // if the current node is after the array, move it one position ahead
        }
        else { throw new NoCurrentItem280Exception("No current item"); }
        //restore the heap;
           deletionhelper(1);
        }






    /**
     * Helper for the regression test.  Verifies the heap property for all nodes.
     */
    private boolean hasHeapProperty() {
        for (int i = 1; i <= count; i++) {
            if (findRightChild(i) <= count) {  // if i Has two children...
                // ... and i is smaller th an either of them, , then the heap property is violated.
                if (items[i].compareTo(items[findRightChild(i)]) < 0) return false;
                if (items[i].compareTo(items[findLeftChild(i)]) < 0) return false;
            } else if (findLeftChild(i) <= count) {  // if n has one child...
                // ... and i is smaller than it, then the heap property is violated.
                if (items[i].compareTo(items[findLeftChild(i)]) < 0) return false;
            } else break;  // Neither child exists.  So we're done.
        }
        return true;
    }

    /**
     * Regression test
     */
    public static void main(String[] args) {

        ArrayedHeap280<Integer> H = new ArrayedHeap280<Integer>(10);

        // Empty heap should have the heap property.
        if (!H.hasHeapProperty()) System.out.println("Does not have heap property.");


//        Insert items 1 through 10, checking after each insertion that
//        the heap property is retained, and that the top of the heap is correctly i.
        for (int i = 1; i <= 10; i++) {
            H.insert(i);

            if (H.item() != i) System.out.println("Expected current item to be " + i + ", got " + H.item());
            if (!H.hasHeapProperty()) System.out.println("Does not have heap property.");
        }
        System.out.println(H);



//
//        // Remove the elements 10 through 1 from the heap, chekcing
//        // after each deletion that the heap property is retained and that
//        // the correct item is at the top of the heap.
        for (int i = 10; i >= 1; i--) {
            // Remove the element i.
            H.deleteItem();

            // If we've removed item 1, the heap should be empty.
            if (i == 1) {
                if (!H.isEmpty()) System.out.println("Expected the heap to be empty, but it wasn't.");
            } else {
                // Otherwise, the item left at the top of the heap should be equal to i-1.
                if (H.item() != i - 1) System.out.println("Expected current item to be " + i + ", got " + H.item());
                if (!H.hasHeapProperty()) System.out.println("Does not have heap property.");
            }
        }

        System.out.println("Regression Test Complete.");
    }
    }








